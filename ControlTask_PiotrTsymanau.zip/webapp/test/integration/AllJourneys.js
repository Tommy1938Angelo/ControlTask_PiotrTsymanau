/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"Worklist/ControlTask_PiotrTsymanau/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"Worklist/ControlTask_PiotrTsymanau/test/integration/pages/Worklist",
	"Worklist/ControlTask_PiotrTsymanau/test/integration/pages/Object",
	"Worklist/ControlTask_PiotrTsymanau/test/integration/pages/NotFound",
	"Worklist/ControlTask_PiotrTsymanau/test/integration/pages/Browser",
	"Worklist/ControlTask_PiotrTsymanau/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "Worklist.ControlTask_PiotrTsymanau.view."
	});

	sap.ui.require([
		"Worklist/ControlTask_PiotrTsymanau/test/integration/WorklistJourney",
		"Worklist/ControlTask_PiotrTsymanau/test/integration/ObjectJourney",
		"Worklist/ControlTask_PiotrTsymanau/test/integration/NavigationJourney",
		"Worklist/ControlTask_PiotrTsymanau/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});